﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace POCVariavelAmbiente
{
    public class DatabaseConnection
    {
        public string Name { get; set; }

        public string ConnectionString { get; set; }

        public string Provider { get; set; }


    }
}
